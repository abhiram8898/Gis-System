<?php
namespace MapMyIndia\Exceptions;

class MMIException extends \Exception {}