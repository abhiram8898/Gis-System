<?php
namespace MapMyIndia;

class Client 
{
    public function test()
    {
        return true;
    }
}
