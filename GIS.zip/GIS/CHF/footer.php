 <!-- jQuery CDN -->
 <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>

 <!-- CODE FOR AJAX -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js">
</script>
<script src="https://js.arcgis.com/4.25"></script>
<script src="../js/script.js"></script>
</body>
</html>